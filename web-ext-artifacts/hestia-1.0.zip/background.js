browser.browserAction.onClicked.addListener((tab) => {
    browser.browserAction.openPopup();
  });
  